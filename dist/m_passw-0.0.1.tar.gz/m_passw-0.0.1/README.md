# sample readme file

[Connection manager to connect to SQL databases via Python, designed for linux RHEL 7.8 server]
[Function connect returns Pyodbc Cursor object, 
[ Parameters (positional): 1. Connection name]
[ Parameters (defined): 2. Optional parameter to debug for any issues]


[Example Call: conn = m_passw.connect('D_D_ETL',debug=True)
