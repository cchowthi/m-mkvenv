
#import python packages

import pandas as pd
import logging
import pyodbc
import base64
import math
import numpy as np
pw_ds = '/biometrics/global/mgarea/data/pwencode.sas7bdat'
def connect(connection_name,server="",debug=False):
	"""
	Connection manager connector function for Python SQL Server Via PyODBC
	Example Call: conns = m_passw.connect('D_D_ETL')
	:param connection_name: Name of connection (refer to password manager for list of names)
	:param server: Default Blank Grab Server from Password Manager - Specify server if needed
	:param debug: Default False - Returns debugging statements if set to True
	"""
	try:
		pw_ds_df = pd.read_sas(pw_ds, format='sas7bdat', index=None, encoding='iso-8859-1', chunksize=None, iterator=False)
		pw_ds_df_sel = pw_ds_df.loc[pw_ds_df['NAME'].str.lower() == connection_name.lower()].replace(np.nan, '', regex=True)
		if pw_ds_df_sel.shape[0] == 0:
			logging.error('Error Finding Connection Name: ' + connection_name + ' was NOT connected. Check Spelling/Name. Use m_passw.list to return all connection names')
		elif pw_ds_df_sel.shape[0] > 1:
			logging.error('Multiple Connections For Name: ' + connection_name + ' was NOT connected. Check Spelling/Name.')
		else:
			con_list = pw_ds_df_sel.values.tolist()[0]
			### connect to connection_name
			### convert base64 encoding to string:
			pw64 = base64.b64decode(con_list[9]).decode("utf-8")
			### Check if server was passed in, use it if it is
			if server:
				con_list[12] = (server)
			### if no server, exit connection
			if con_list[12] == "":
				logging.error('No Server Specified for: ' + connection_name + ' was NOT connected. Update password manager to correct server.')
			else:
				if con_list[13] == "":
					db_connection = (pyodbc.connect('Driver={ODBC Driver 17 for SQL Server};DSN=' + con_list[3] + ';UID=' + con_list[4] + ';PWD='+ pw64 + ';SERVER=' + con_list[12] +';')) 
				else:
					db_connection = (pyodbc.connect('Driver={ODBC Driver 17 for SQL Server};DATABASE=' + con_list[13] + ';UID=' + con_list[4] + ';PWD='+ pw64 + ';SERVER=' + con_list[12] +';')) 
				cursor = db_connection.cursor()
				#return cursor
				return db_connection
		
	except:
		if debug == True:  # Use some boolean to represent dev state, such as DEBUG in Django
			raise
		logging.error('Error Finding Connection Name: ' + connection_name + ' was NOT connected.')

def list(debug=False):
	"""
	Connection manager listing of connections
	Example Call: conns = m_passw.list()
	:param debug: Default False - Returns debugging statements if set to True
	"""
	try:
		pw_ds_df = pd.read_sas(pw_ds, format='sas7bdat', index=None, encoding='utf-8', chunksize=None, iterator=False)
		conn_list = pw_ds_df.reset_index()[['NAME','DESCRIPTION']].values.tolist()
		return conn_list
	except:
		if debug == True:
			raise
		logging.error('Error Listing Connections.')

if __name__ == '__main__':
	pass
