# note the “.” before the module (file) name because Python 3 is strict about the relative paths
from .m_passw import connect
from .m_passw import list


__all__ = ['connect','list']