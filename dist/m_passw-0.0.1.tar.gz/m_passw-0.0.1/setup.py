import setuptools


setuptools.setup(
    name="m_passw",
    version="0.0.1",
    author="kmiller05",
    author_email="kevin.miller@gilead.com",
    description="Connection manager package for stat programming",
    long_description="Connection manager to connect to SQL databases via Python, designed for linux RHEL 7.8 server",
    long_description_content_type="text/markdown",
    url="normally your pip url. if not, use your company url.",
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
)
